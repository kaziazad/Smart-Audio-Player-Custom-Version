document.addEventListener('DOMContentLoaded', function() {
  const radios = document.querySelectorAll('input[type="radio"]');
  radios.forEach(radio => {
      radio.addEventListener('change', function() {
          radios.forEach(r => {
              if (r.checked) {
                  r.parentElement.classList.add('highlight');
              } else {
                  r.parentElement.classList.remove('highlight');
              }
          });
      });
  });
});




// *****************
var player = $('.player'),
  audio = player.find('audio'),
  duration = $('.duration'),
  currentTime = $('.current-time'),
  progressBar = $('.progress span'),
  mouseDown = false,
  rewind, showCurrentTime;


function secsToMins(time) {
var int = Math.floor(time),
    mins = Math.floor(int / 60),
    secs = int % 60,
    newTime = mins + ':' + ('0' + secs).slice(-2);

return newTime;
}


function getCurrentTime() {
var currentTimeFormatted = secsToMins(audio[0].currentTime),
    currentTimePercentage = audio[0].currentTime / audio[0].duration * 100;

currentTime.text(currentTimeFormatted);
progressBar.css('width', currentTimePercentage + '%');

if (player.hasClass('playing')) {
  showCurrentTime = requestAnimationFrame(getCurrentTime);
} else {
  cancelAnimationFrame(showCurrentTime);
}
}


audio.on('loadedmetadata', function() {
var durationFormatted = secsToMins(audio[0].duration);
duration.text(durationFormatted);
}).on('ended', function() {
if ($('.repeat').hasClass('active')) {
  audio[0].currentTime = 0;
  audio[0].play();
} else {
  player.removeClass('playing').addClass('paused');
  audio[0].currentTime = 0;
}
});


$('button').on('click', function() {
var self = $(this);

if (self.hasClass('play-pause') && player.hasClass('paused')) {
  player.removeClass('paused').addClass('playing');
  audio[0].play();
  getCurrentTime();
  // ***** visual animation start
  const bar = document.querySelectorAll(".bar");
  for (let i = 0; i < bar.length; i++) {
    bar.forEach((item, j) => {
      // Random move
      item.style.animationDuration = `${Math.random() * (0.7 - 0.2) + 0.2}s`; // Change the numbers for speed / ( max - min ) + min / ex. ( 0.5 - 0.1 ) + 0.1
    });
  }
  // ****
} else if (self.hasClass('play-pause') && player.hasClass('playing')) {
  player.removeClass('playing').addClass('paused');
  audio[0].pause();
   // ***** visul animation pouse
   const bar = document.querySelectorAll(".bar");
   for (let i = 0; i < bar.length; i++) {
     bar.forEach((item, j) => {
       // Random move
       item.style.animationDuration = `0s`; // Change the numbers for speed / ( max - min ) + min / ex. ( 0.5 - 0.1 ) + 0.1
     });
   }
   // ****
}

if (self.hasClass('shuffle') || self.hasClass('repeat')) {
  self.toggleClass('active');
}
}).on('mousedown', function() {
var self = $(this);

if (self.hasClass('ff')) {
  player.addClass('ffing');
  audio[0].playbackRate = 2;
}

if (self.hasClass('rw')) {
  player.addClass('rwing');
  rewind = setInterval(function() { audio[0].currentTime -= .3; }, 100);
}
}).on('mouseup', function() {
var self = $(this);

if (self.hasClass('ff')) {
  player.removeClass('ffing');
  audio[0].playbackRate = 1;
}

if (self.hasClass('rw')) {
  player.removeClass('rwing');
  clearInterval(rewind);
}
});


player.on('mousedown mouseup', function() {
mouseDown = !mouseDown;
});


progressBar.parent().on('click mousemove', function(e) {
var self = $(this),
    totalWidth = self.width(),
    offsetX = e.offsetX,
    offsetPercentage = offsetX / totalWidth;

if (mouseDown || e.type === 'click') {
  audio[0].currentTime = audio[0].duration * offsetPercentage;


  // *****
  const bar = document.querySelectorAll(".bar");
  for (let i = 0; i < bar.length; i++) {
    bar.forEach((item, j) => {
      // Random move
      item.style.animationDuration = `${Math.random() * (0.7 - 0.2) + 0.2}s`; // Change the numbers for speed / ( max - min ) + min / ex. ( 0.5 - 0.1 ) + 0.1
    });
  }
  // ****


  if (player.hasClass('paused')) {
    progressBar.css('width', offsetPercentage * 100 + '%');
  }
}
});

const audioPlayer = document.getElementById('current_player');

      // Add an event listener for the 'ended' event
      audioPlayer.addEventListener('ended', function() {
    
  
   const bar = document.querySelectorAll(".bar");
   for (let i = 0; i < bar.length; i++) {
     bar.forEach((item, j) => {
//          // Random move
       item.style.animationDuration = `0s`; // Change the numbers for speed / ( max - min ) + min / ex. ( 0.5 - 0.1 ) + 0.1
     });
   }
   
       
         });
